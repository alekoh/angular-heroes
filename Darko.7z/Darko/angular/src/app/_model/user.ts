/**
 * Created by aleksandar.mechkaros on 4/10/2017.
 */

export class User {
  _id: string;
  fname: string;
  lname: string;
  username: string;
  password: string;
  token: string;
}
