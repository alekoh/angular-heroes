"use strict";
/**
 * Created by aleksandar.mechkaros on 4/10/2017.
 */
Object.defineProperty(exports, "__esModule", { value: true });
var User = (function () {
    function User() {
    }
    return User;
}());
exports.User = User;
