"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Token = (function () {
    function Token(access_token, token_type) {
        this.access_token = access_token;
        this.token_type = token_type;
    }
    return Token;
}());
exports.Token = Token;
