import { Component } from "@angular/core";


@Component({
  selector: "heroes-component-main",
  template: `<router-outlet>
              </router-outlet>`
})

export class HeroesComponentMain {
}
