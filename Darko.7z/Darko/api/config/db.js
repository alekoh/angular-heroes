/**
 * Created by aleksandar.mechkaros on 4/12/2017.
 */
module.exports = {
    url: "mongodb://alekoh:lol123ok321alek@ds157500.mlab.com:57500/angular",
};
