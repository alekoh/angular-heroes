/**
 * Created by aleksandar.mechkaros on 5/25/2017.
 */
module.exports = {
    database: 'mongodb://alekoh:lol123ok321alek@ds151951.mlab.com:51951/complete-heroes',
    secret: 'yoursecret',
    userid: ''
};