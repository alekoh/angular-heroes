# oauth2-backend
A simple nodejs app serving as a backend for our angular app.

For further details - http://tphangout.com/?p=392
